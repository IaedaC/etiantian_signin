
<?php
function curl_post($header,$data,$url)
    {
     $ch = curl_init();
     $res= curl_setopt ($ch, CURLOPT_URL,$url);
     curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
     curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
     curl_setopt ($ch, CURLOPT_HEADER, 0);
     curl_setopt($ch, CURLOPT_POST, 0);
     curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
     curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
     curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
     $result = curl_exec ($ch);
     curl_close($ch);
     if ($result == NULL) {
      return 0;
     }
     return $result;
    } 
$url="http://fenxi.haofenshu.com/report/obt/v1/exam/irrank?examid={$_GET["examid"]}&grade=&org=0";


     $header = array(
        'Content-Type:application/json',
        'Cookie:你的cookie',
      
      'User-Agent: Mozilla/4.0 (compatible; MSIE .0; Windows NT 6.1; Trident/4.0; SLCC2;)'); 
    $data = '{
	"filters":{
		"offset":1,
		"limit":9999,
		"tpkey":"totalScore",
		"tgkeys":[找xinool获取],
		"search":"'.$_GET["xh"].'",
		"order":{
			"key":"score",
			"rule":"desc"
		},
		"isEs":false
	}
}';

    
    $ret = curl_post($header, $data,$url);
header('Content-type:text/json');  
echo $ret;

