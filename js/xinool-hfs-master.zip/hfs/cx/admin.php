<?php
header("content-type: text/html; charset=utf-8");
header("HTTP/1.1 302 Moved Permanently"); 
header("Location: http://你的域名/cx/json/admin.php?examid={$_GET["examid"]}&xh={$_GET["xh"]}"); 
?>
<?php
$ch =curl_init();
curl_setopt($ch,CURLOPT_URL,'http://你的域名/cx/km-1.php?examid='.$_GET["examid"].'');
$header = array();
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
curl_setopt($ch,CURLOPT_COOKIE,'你的cookie');
$content = curl_exec($ch);
?>
