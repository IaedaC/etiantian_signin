<?php
header("Content-type:text/html;Charset=utf8");
$ch =curl_init();
curl_setopt($ch,CURLOPT_URL,'http://fenxi.haofenshu.com/report/obt/v1/exam/info?examid='.$_GET["examid"].'&org=0');
$header = array();
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
curl_setopt($ch,CURLOPT_COOKIE,'你的cookie');
$content = curl_exec($ch);
echo $content;
?>
