<!DOCTYPE html>

<html lang="en" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>好分数成绩查询</title>


	</head>
<body style="">
<div class="preloader" style="display: none;">
  <span class="preloader-spin"></span>
</div>
<div class="site"><div class="service-area bg2 sp">
<div class="container">
<div class="section-title">
<h2>好分数成绩查询</h2>

</div>
<div class="row">
	
<div class="col-lg-4 col-md-6 single-service">
<div class="inner">

 <div class="container">
	 
           <center>       <form method="get" action="admin.php" class="form-validate" id="loginFrom">
                    <div class="form-group">
                      <input id="login-username" type="text" name="xh" required data-msg="请输姓名" placeholder="姓名" value="" class="input-material">
                    </div>
                    <div class="form-group">
                      <input id="login-password" type="text" name="examid" required data-msg="请输入examID" placeholder="examID" class="input-material">
			   </div>
                    <button id="login" type="submit" class="btn btn-primary">查询</button>
			   </center>
		
</form>
              
                </div>
		</div>
	

</div>
	</div>
	<div class="row">
	
<div class="col-lg-4 col-md-6 single-service">
<div class="inner">
	<center><h4>点击查询后请等待10s</h4></center>
	</div>
	

</div>
	</div>


</div>
</div>




</div><footer>
  <div class="footer-bottom">
  <div class="container">
<div class="row">
<div class="col-lg-6">

</div>
</div>
</div>
</div>
</footer>
</div>


</body></html>
